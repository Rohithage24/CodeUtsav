import express from "express";

const userEmotionSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    day: {
      type: String,
      required: true,
    },

    mood: {
      type: String,
      enum: ["happy", "sad", "angry", "excited", "relaxed", "bored"],
      required: true,
    },
    Question:{
         type: String,
      required: true,
    },

    struggle: {
      type: String,
      required: true,
    },

    note: {
      type: String,
    },
  },
  { timestamps: true }
);


userEmotionSchema.index({ userId: 1, day: 1 }, { unique: true });

const userEmotionMOdel = mongoose.model("UserEmotion", userEmotionSchema);

export default userEmotionMOdel;
import express from "express";
import { saveDailyEmotion, getTodayEmotion ,updateBookFeedback } from "../Controller/userEmo.controller.js";

const router = express.Router();

// 🔹 Save daily emotion
router.post("/save", saveDailyEmotion);

// 🔹 Get today emotion + recommendations
// router.get("/today", getTodayEmotion);
router.post("/feedback", updateBookFeedback);

export default router;
import userEmotionModel from "../models/userEmotation.model.js";
import AuthUser from "../models/auth.model.js";
import Recommendation from "../models/recommendation.model.js";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const getToday = () => new Date().toISOString().split("T")[0];

// ─────────────────────────────────────────────────────────────
// 🤖 AI BOOK RECOMMENDATION
// Receives full emotion context → returns array of book objects
// ─────────────────────────────────────────────────────────────
const getBooksByMood = async (mood, struggle, note, question, answer) => {
  try {
    const prompt = `
You are a compassionate book recommendation assistant.

A user answered these daily check-in questions:
- Question: "${question}"
- Their answer: "${answer}"
- Their mood today: "${mood}"
- Struggle they faced: "${struggle}"
- Extra note: "${note || "none"}"

Based on all of the above, suggest exactly 5 books that would help or resonate with this person.

Respond ONLY as a valid JSON array. No explanation, no numbering, no markdown. Example format:
[
  { "name": "Book Title", "reason": "One sentence why this fits the user" },
  { "name": "Book Title", "reason": "One sentence why this fits the user" }
]
`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
    });

    const raw = response.choices[0].message.content.trim();

    // Strip markdown code fences if model wraps in ```json ... ```
    const cleaned = raw.replace(/^```json|^```|```$/gm, "").trim();

    const parsed = JSON.parse(cleaned);

    // Shape into bookSchema format
    return parsed.map((b) => ({
      name: b.name,
      feedback: {
        liked: null,
        rating: null,
        note: "",
        categoryFeeling: "",
      },
    }));
  } catch (error) {
    console.error("OpenAI / parse error:", error.message);
    // Fallback books so response never breaks
    return [
      { name: "Atomic Habits",  feedback: { liked: null, rating: null, note: "", categoryFeeling: "" } },
      { name: "Deep Work",      feedback: { liked: null, rating: null, note: "", categoryFeeling: "" } },
      { name: "The Alchemist",  feedback: { liked: null, rating: null, note: "", categoryFeeling: "" } },
    ];
  }
};

// ─────────────────────────────────────────────────────────────
// POST /api/emotion/save
// Called after user answers the daily questions
// ─────────────────────────────────────────────────────────────
export const saveDailyEmotion = async (req, res) => {
  try {
    const { mood, struggle, note, question, answer } = req.body;
    const userId = req.user.id;
    const today  = getToday();

    // ── Validate user ──────────────────────────────────────
    const user = await AuthUser.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    // ── Reset flag on new day, then mark visited ───────────
    if (user.lastVisitDate !== today) {
      user.dayVisit      = false;
      user.lastVisitDate = today;
    }
    user.dayVisit = true;
    await user.save();

    // ── Save / update today's emotion ──────────────────────
    const emotionData = await userEmotionModel.findOneAndUpdate(
      { userId, day: today },
      { $set: { userId, day: today, mood, struggle, note, question, answer } },
      { new: true, upsert: true }
    );

    // ── Generate books via OpenAI ──────────────────────────
    const books = await getBooksByMood(mood, struggle, note, question, answer);

    // ── Save / update recommendation for today ─────────────
    const recommendation = await Recommendation.findOneAndUpdate(
      { userId, day: today },
      { $set: { userId, day: today, mood, struggle, note, books } },
      { new: true, upsert: true }
    );

    return res.json({
      message: "Emotion saved for today",
      emotion: emotionData,
      recommendations: recommendation.books,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// ─────────────────────────────────────────────────────────────
// GET /api/emotion/today
// First visit  → ask questions
// Second visit → return saved emotion + book recommendations
// ─────────────────────────────────────────────────────────────
export const getTodayEmotion = async (req, res) => {
  try {
    const userId = req.user.id;
    const today  = getToday();

    // ── Validate user ──────────────────────────────────────
    const user = await AuthUser.findById(userId);
    if (!user) return res.status(404).json({ message: "User not found" });

    // ── Reset flag on new day ──────────────────────────────
    if (user.lastVisitDate !== today) {
      user.dayVisit      = false;
      user.lastVisitDate = today;
      await user.save();
    }

    // ── Check if emotion exists for today ──────────────────
    const emotionData = await userEmotionModel.findOne({ userId, day: today });

    // 🟡 FIRST VISIT → ask questions
    if (!emotionData) {
      return res.json({
        firstVisitToday: true,
        askQuestions:    true,
        questions: [
          { id: "question", text: "How was your day today?" },
          { id: "struggle", text: "What kind of struggle did you face?" },
        ],
      });
    }

    // 🟢 SECOND VISIT → return saved data + books from DB (no OpenAI call)
    const recommendation = await Recommendation.findOne({ userId, day: today });

    return res.json({
      firstVisitToday: false,
      askQuestions:    false,

      user: { userId: user._id },

      emotion: {
        mood:     emotionData.mood,
        struggle: emotionData.struggle,
        note:     emotionData.note,
        question: emotionData.question,
        answer:   emotionData.answer,
      },

      recommendations: recommendation ? recommendation.books : [],
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
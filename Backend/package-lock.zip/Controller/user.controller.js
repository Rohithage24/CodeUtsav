import dotenv from "dotenv";
import AuthUser from "../models/auth.model.js";
import Profile from "../models/user.model.js";

dotenv.config();


/**
 * Create User Profile
 */
export const createProfile = async (req, res) => {
  try {

    const { authID, name, email, password, mobile } = req.body;
    console.log(req.body);
    

    // 1️⃣ Validate required fields
    if (!authID || !mobile) {
      return res.status(400).json({
        success: false,
        message: "authID and mobile are required"
      });
    }

    // 2️⃣ Check Auth User exists
    const authUser = await AuthUser.findById(authID);

    if (!authUser) {
      return res.status(404).json({
        success: false,
        message: "Authentication user not found"
      });
    }

    // 3️⃣ Check if profile already exists
    const existingProfile = await Profile.findOne({ authID });

    if (existingProfile) {
      return res.status(400).json({
        success: false,
        message: "Profile already exists"
      });
    }

    // 4️⃣ Hash password (if provided)
    let hashedPassword = null;

    // if (password) {
    //   const salt = await bcrypt.genSalt(10);
    //   hashedPassword = await bcrypt.hash(password, salt);
    // }

    // 5️⃣ Create profile
    const newProfile = new Profile({
      authID,
      name,
      email,
      password: Password,
     
      mobile
    });

    await newProfile.save();

    return res.status(201).json({
      success: true,
      message: "Profile created successfully",
      data: newProfile
    });

  } catch (error) {

    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Server error"
    });

  }
};



// =============================================================================
//  GET /api/profile/getProfile/:authID
// =============================================================================
export const getProfile = async (req, res) => {
  try {

    const { authID } = req.params;
    console.log(authID);
    
    // 1️⃣ Validate authID
    if (!authID) {
      return res.status(400).json({
        success: false,
        message: "authID is required"
      });
    }

    // 2️⃣ Find profile
    const profile = await Profile.findOne({ authID });

    if (!profile) {
      return res.status(404).json({
        success: false,
        message: "Profile not found"
      });
    }

    // 3️⃣ Return response
    return res.status(200).json({
      success: true,
      message: "Profile fetched",
      data: {
        user: {
          id: profile._id,
          authID: profile.authID,
          name: profile.name,
          email: profile.email,
          mobile: profile.mobile,
          createdAt: profile.createdAt
        }
      }
    });

  } catch (error) {

    console.error("getProfile error:", error);

    return res.status(500).json({
      success: false,
      message: "Server error"
    });

  }
};



// =============================================================================
//  PATCH /api/profile/updateProfile        (Protected)
//  Body: { name: "Rohit", address: "Pune" }
// =============================================================================
export const updateProfile = async (req, res) => {
  try {

    const { name, email, serviceNo, address } = req.body;

    const profile = await Profile.findOne({ authID: req.user._id });

    if (!profile) {
      return res.status(404).json({
        success: false,
        message: "Profile not found"
      });
    }

    if (name && String(name).trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: "Name must be at least 2 characters"
      });
    }

    // Update fields if provided
    if (name) profile.name = String(name).trim();
    if (email) profile.email = String(email).trim().toLowerCase();
   

    await profile.save();

    return res.status(200).json({
      success: true,
      message: "Profile updated successfully",
      data: {
        user: {
          id: profile._id,
          authID: profile.authID,
          name: profile.name,
          email: profile.email,
          mobile: profile.mobile,
        }
      }
    });

  } catch (error) {

    console.error("updateProfile error:", error);

    return res.status(500).json({
      success: false,
      message: "Server error"
    });

  }
};


